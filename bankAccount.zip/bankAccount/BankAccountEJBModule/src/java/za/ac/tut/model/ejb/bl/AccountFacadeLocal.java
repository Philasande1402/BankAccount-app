/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.ejb.bl;

import java.util.List;
import javax.ejb.Local;
import za.ac.tut.model.entities.Account;

/**
 *
 * @author Philasande
 */
@Local
public interface AccountFacadeLocal {

    void create(Account account);
    void edit(Account account);
    void remove(Account account);

    Account find(Object id);
    Account find(String accountNumber);

    List<Account> findAll();

    List<Account> findRange(int[] range);
    
    List<Account> findByTypeAndMinimumBalance(String accountType, Double minBalance);
    List<Account> findByAccountHolderDetails(String firstName, String lastName);

    int count();
    
}
