/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import za.ac.tut.model.entities.Account;

/**
 *
 * @author Philasande
 */
@Stateless
public class AccountFacade extends AbstractFacade<Account> implements AccountFacadeLocal {

    @PersistenceContext(unitName = "BankAccountEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AccountFacade() {
        super(Account.class);
    }

    @Override
    public Account find(String accountNumber) {
        TypedQuery<Account> query = (TypedQuery<Account>) em.createQuery("SELECT a FROM Account a WHERE a.accountNumber = :accountNumber",Account.class);
        query.setParameter("accountNumber", accountNumber);
        List<Account> account = query.getResultList();
        return account.isEmpty()?null :account.get(0);
    }

    @Override
    public List<Account> findByTypeAndMinimumBalance(String accountType, Double minBalance) {
       TypedQuery<Account> query = (TypedQuery<Account>) em.createQuery("SELECT a FROM Account a WHERE a.accountType= :accountType AND a.balance >= :minBalance",Account.class);
       query.setParameter("accountType", accountType);
       query.setParameter("minBalance", minBalance);
       
       return query.getResultList();
    }

    @Override
    public List<Account> findByAccountHolderDetails(String firstName, String lastName) {
        TypedQuery<Account> query =(TypedQuery<Account>) em.createQuery("SELECT a FROM Account a WHERE a.accountHolder.firstName = :firstName AND a.accountHolder.lastName = :lastName",Account.class);
        query.setParameter("firstName", firstName);
        query.setParameter("lastName", lastName);
        
        return query.getResultList();
    }
    
}
