/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.security;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author Philasande
 */
@Named
@SessionScoped
public class RoleManager implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String currentRole;
    
    //constant for roles
    public static final String ROLE_ADMIN = "admin";
    public static final String ROLE_MANAGER = "manager";

    public RoleManager() {
        this.currentRole = ROLE_ADMIN;
    }

    public String getCurrectRole() {
        return currentRole;
    }

    public void setCurrectRole(String currentRole) {
        this.currentRole = currentRole;
    }
    
    public boolean isAdmin(String currentRole){
        return ROLE_ADMIN.equals(currentRole);
    }
   
    public boolean isManager(String currectRole){
        return ROLE_MANAGER.equals(currectRole);
    }
    
    public void switchToAdmin() {
        this.currentRole = ROLE_ADMIN;
    }
    
    public void switchToManager() {
        this.currentRole = ROLE_MANAGER;
    }
}
