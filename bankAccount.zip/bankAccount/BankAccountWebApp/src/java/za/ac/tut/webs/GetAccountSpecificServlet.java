/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.webs;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.ejb.bl.AccountFacadeLocal;
import za.ac.tut.model.entities.Account;

/**
 *
 * @author Philasande
 */
public class GetAccountSpecificServlet extends HttpServlet {
@EJB
    private AccountFacadeLocal afl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accountType = request.getParameter("accType");
        Double balance = Double.parseDouble(request.getParameter("balance"));
        
        List<Account> acc = afl.findByTypeAndMinimumBalance(accountType, balance);
        request.setAttribute("acc", acc);
        
        RequestDispatcher disp = request.getRequestDispatcher("get_account_specifics_outcome.jsp");
        disp.forward(request, response);
    }
                
}
