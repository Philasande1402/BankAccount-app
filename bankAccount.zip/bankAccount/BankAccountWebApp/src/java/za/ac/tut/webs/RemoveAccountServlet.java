/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.webs;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.ejb.bl.AccountFacadeLocal;
import za.ac.tut.model.entities.Account;

/**
 *
 * @author Philasande
 */
public class RemoveAccountServlet extends HttpServlet {

@EJB
    private AccountFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accountNumber = request.getParameter("accNo");
        
        Account account = createAccount(accountNumber);
        afl.remove(account);
        
        RequestDispatcher disp = request.getRequestDispatcher("revome_account_servlet.jsp");
        disp.forward(request, response);
    }

    private Account createAccount(String accountNumber) {
        Account acc = afl.find(accountNumber);
        return acc;
    }

    
}
