/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.webs;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.ejb.bl.AccountFacadeLocal;
import za.ac.tut.model.entities.Account;
import za.ac.tut.model.entities.AccountHolder;

/**
 *
 * @author Philasande
 */
public class EditAccountServlet extends HttpServlet {
@EJB
    private AccountFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accountNumber = request.getParameter("accNo");
        String surname = request.getParameter("surname");
        char status = request.getParameter("status").charAt(0);
        
        Account account = createAccount(accountNumber,surname,status);
        afl.edit(account);
        
        request.setAttribute("accountNumber", accountNumber);
        RequestDispatcher disp = request.getRequestDispatcher("edit_account_outcome.jsp");
        disp.forward(request, response);
        
    }

    private Account createAccount(String accountNumber, String surname, char status) {
        Account acc = afl.find(accountNumber);
        AccountHolder ah = new AccountHolder();
        ah.setLastName(surname);
        ah.setMaritalStatus(status);
        
        acc.setAccountHolder(ah);
        
        return acc;
    }
                
}
