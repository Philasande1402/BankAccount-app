/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.webs;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.ejb.bl.AccountFacadeLocal;
import za.ac.tut.model.entities.Account;
import za.ac.tut.model.entities.AccountHolder;

/**
 *
 * @author Philasande
 */
public class AddAccountServlet extends HttpServlet {
@EJB
    private AccountFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    try {
        String accountNumber = request.getParameter("accNo");
        String accountType = request.getParameter("accType");
        Double balance =Double.parseDouble(request.getParameter("balance"));
        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String gender = request.getParameter("gender");
        Integer age =Integer.parseInt(request.getParameter("age"));
        char status = request.getParameter("status").charAt(0);
        String pubDate = request.getParameter("dates");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date birthDate= dateFormat.parse(pubDate);
        
        Account account = createAccount(accountNumber,accountType,balance,id,name,surname,gender,age,status,birthDate);
        afl.create(account);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_account_outcome.jsp");
        disp.forward(request, response);
        
    } catch (ParseException ex) {
        Logger.getLogger(AddAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
    }
        
        
    }

    private Account createAccount(String accountNumber, String accountType, Double balance, Long id, String name, String surname, String gender, Integer age, char status,Date birthDate) {
        Account acc = new Account();
        AccountHolder ah = new AccountHolder();
        ah.setFirstName(name);
        ah.setLastName(surname);
        ah.setGender(gender);
        ah.setAge(age);
        ah.setId(id);
        ah.setDateOfBirth(birthDate);
        ah.setMaritalStatus(status);
        
        acc.setAccountNumber(accountNumber);
        acc.setAccountType(accountType);
        acc.setBalance(balance);
        acc.setAccountHolder(ah);
        acc.setCreationDate(new Date());
        
        return acc;
    }
        
            
   
}
