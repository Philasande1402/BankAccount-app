/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.webs;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.ejb.bl.AccountFacadeLocal;
import za.ac.tut.model.entities.Account;

/**
 *
 * @author Philasande
 */
public class GetAllAccountServlet extends HttpServlet {
@EJB
    private AccountFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Account> account = afl.findAll();
        
        request.setAttribute("account", account);
        
        RequestDispatcher disp = request.getRequestDispatcher("get_account_list_outcome.jsp");
        disp.forward(request, response);
    }

}
