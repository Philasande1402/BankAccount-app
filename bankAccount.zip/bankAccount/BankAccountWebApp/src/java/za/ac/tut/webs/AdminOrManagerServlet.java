/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.webs;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.security.RoleManager;

/**
 *
 * @author Philasande
 */
@WebServlet(name = "AdminOrManagerServlet", urlPatterns = {"/AdminOrManagerServlet.do"})
public class AdminOrManagerServlet extends HttpServlet {
@Inject
    private RoleManager roleManager;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String selectedRole = request.getParameter("option");
        
        HttpSession session = request.getSession(true);
        session.setAttribute("roleManager", roleManager);
        
        
        if (roleManager.isAdmin(selectedRole)) {
            roleManager.switchToAdmin();
            RequestDispatcher disp = request.getRequestDispatcher("admin.jsp");
            disp.forward(request, response);
        } else if (roleManager.isManager(selectedRole)) {
            roleManager.switchToManager();
            RequestDispatcher disp = request.getRequestDispatcher("manager.jsp");
            disp.forward(request, response);
        } else {
            // Handle invalid input
            request.setAttribute("errorMessage", "Invalid role selected");
            RequestDispatcher disp = request.getRequestDispatcher("admin_manager.jsp");
            disp.forward(request, response);
        }
    }

}
